# 🧠 Prospección de Datos Abiertos – Ayuntamiento de Arganda del Rey
Automatiza la recopilación de datos abiertos (Contratos Menores) del Ayuntamiento de Arganda del Rey.
Detecta nuevos registros y envía un correo HTML con las novedades usando la API de Gmail.